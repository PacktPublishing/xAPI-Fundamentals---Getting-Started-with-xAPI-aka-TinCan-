// Variables
var name = "Sammy McGee";
var email = "jeffbatt@gmail.com"

// Page Load Function
function pageLoaded(){
	
}

// Send statement
function sendOverStatement(){
	
	var statement = {
		"actor": {  
	        "mbox": "mailto:" + email,  
	        "name": name,  
	        "objectType": "Agent"  
	    },  
	    "verb": {  
	        "id": "http://adlnet.gov/expapi/verbs/interacted",  
	        "display": {"en-US": "interacted"}  
	    },  
	    "object": {  
	        "id": "http://punklearning.com/xapi/simple_button",  
	        "definition": {  
	            "name": {"en-US": "Simple button example"},  
	            "description": {"en-US": "Simple button example xAPI Button"}  
	        },  
	        "objectType": "Activity"  
	    }  
	}

	alert('Statement has been sent over')

	ADL.XAPIWrapper.sendStatement(statement);

}

// On Blur Events
function saveName(){
	name = document.getElementById('nameEntered').value;
}

function saveEmail(){
	email = document.getElementById('userEmail').value;
}