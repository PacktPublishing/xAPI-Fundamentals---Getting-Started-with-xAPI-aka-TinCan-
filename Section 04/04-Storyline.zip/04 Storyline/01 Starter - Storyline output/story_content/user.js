function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6QN3uczv7YU":
        Script1();
        break;
  }
}

function Script1()
{
  /*Get player to reference*/
var player = GetPlayer();

var userName = player.GetVar("userName");
var emailAddress = player.GetVar("emailAddress");

/*Statement*/
var runCode = {  
    "actor": {  
        "mbox": "mailto:"+emailAddress,  
        "name": userName,  
        "objectType": "Agent"  
    },  
    "verb": {  
        "id": "http://activitystrea.ms/schema/1.0/experienced",  
        "display": {"en-US": "experienced"}  
    },  
    "object": {  
        "id": "http://purdue.edu/courses/Ethical_Decision_Making",  
        "definition": {  
            "name": {"en-US": "The Ethical Decision Making Introduction page"},  
            "description": {"en-US": "The learner visited the introduction page within the Ethical Decision Making course."}  
        },  
        "objectType": "Activity"  
    }  
};

ADL.XAPIWrapper.sendStatement(runCode);
}

