var statementName = {
	"actor": {
	    "name": window.cpAPIInterface.getVariableValue("userName"),
		"mbox": window.cpAPIInterface.getVariableValue("emailAddress")
	    "objectType": "Agent"
	},
	"verb": {
	    "id": "http://adlnet.gov/expapi/verbs/completed",
	    "display": {
	        "en-US": "completed"
	    }
	},
	"object": {
	    "id": "http://adlnet.gov/expapi/activities/example",
	    "definition": {
	        "name": {
	            "en-US": "Example Activity"
	        },
	        "description": {
	            "en-US": "Example activity description"
	        }
	    },
	    "objectType": "Activity"
	}
};
ADL.XAPIWrapper.sendStatement(statementName); 