function pageLoaded(){
    // Code goes here
}